
class DataNotAvailable(Exception):
    pass


class NoResultsInDir(Exception):
    pass
