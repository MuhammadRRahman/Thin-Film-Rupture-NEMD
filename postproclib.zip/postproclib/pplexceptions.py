class DataNotAvailable(Exception):
    pass

class NoResultsInDir(Exception):
    pass

class DataMismatch(Exception):
    pass

class ScriptMissing(Exception):
    pass

class OutsideRecRange(Exception):
    pass
